import asyncio
from dotenv import load_dotenv

load_dotenv()

async def main():
    from app.src import dp
    from loader import bot

    await dp.start_polling(bot)

if __name__ == "__main__":

    asyncio.run(main())
