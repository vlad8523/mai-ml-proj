import os
import pickle
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

tokenizer = RegexpTokenizer(r'\w+')
sw = set(stopwords.words('russian'))
ps = PorterStemmer()

class MovieRatingPrediction():
    def __init__(self):
        with open(r"app/models/pickle_model.pkl", 'rb') as file:
            self.model = pickle.load(file)
        with open(r"app/models/pickle_vectorizer.pkl", 'rb') as file:
            self.cv = pickle.load(file)

    def get_useful_words(self, text):
        text = text.lower()
        # tokenization
        word_list = tokenizer.tokenize(text)

        # stop word removal
        useful_words = [w for w in word_list if w not in sw]

        # stemming
        stemmed_words = [ps.stem(w) for w in useful_words]

        return stemmed_words

    def predict(self, data): 
        Vec = self.cv.transform([data]).toarray()
        return self.model.predict(Vec)