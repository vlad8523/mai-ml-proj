from .wrapper import MovieRatingPrediction

__all__ = ['MovieRatingPrediction']