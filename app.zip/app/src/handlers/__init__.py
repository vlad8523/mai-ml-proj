from .main_bot import dp

__all__ = ['dp']