from aiogram import types
from aiogram.filters.command import Command

from app.loader import dp, predictor


@dp.message(Command('start'))
async def start(message: types.Message):
    await message.answer(text="Start")
    await message.delete()


@dp.message()
async def any_message(message: types.Message):
    await message.answer(text=predictor.predict(message.text))
